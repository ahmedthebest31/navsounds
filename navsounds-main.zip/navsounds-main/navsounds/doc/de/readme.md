# nav Sounds
This is an NVDA screen reader add-on that 
providing navigation sounds and keyboard typing sounds. 
You can hear different sounds based on the roles of the elements you interact with,
Also allow you to play different keyboard sound as you type.
with the ability to customize everything.

 
## About


This add-on is inspired by the abandoned "objsounds" add-on created by Tyler Spivey. Since that add-on hasn't been updated for a long time, I decided to create this add-on to continue providing similar functionality while keeping up with the changes in the NVDA screen reader.

created by Ahmed Samy (AhmedTheBest)
email: ahmedthebest31@gmail.com
with a Contribution from mesteranas
[github]("https://github.com/ahmedthebest31/navsounds")
[donation]("https://www.paypal.me/ahmedthebest31")

Easily switch between enabling and disabling object sounds and   keyboard typing sound   with a simple keyboard gesture NVDA+alt+n and you can customize it as you want from open nvda menue Preferences  subMenu / Input gestures navigation sounds.   
Access a settings page where you can choose from various navigation sound packages / keyboard typing sound effects and configure additional options.
 includes a selection of sound packages / typing keyboard sound effects, and you can even create and add your custom packages.


Contributions to this project are welcome! If you find a bug, have an idea for an improvement, or want to contribute in any other way, please feel free to open an issue or submit a pull request.

Special thanks to  [mesteranas](https://github.com/mesteranas/) for his wonderful Contributions in developing this add-on with me.
