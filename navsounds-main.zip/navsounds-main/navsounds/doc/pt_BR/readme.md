# sons de navegação
Este é um complemento do leitor de tela do NVDA que
fornece sons de navegação e sons de digitação no teclado.
Você pode ouvir sons diferentes com base nas funções dos elementos com os quais interage,
Também permite que você reproduza sons de teclado diferentes enquanto digita.
com a capacidade de personalizar tudo.
 
##Sobre


Este complemento é inspirado no complemento abandonado "objsounds" criado por Tyler Spivey. Como esse complemento não é atualizado há muito tempo, decidi criar este complemento para continuar fornecendo funcionalidades semelhantes e, ao mesmo tempo, acompanhar as mudanças do leitor de telas NVDA.

criado por Ahmed Samy (AhmedTheBest)
email: ahmedthebest31@gmail.com
com contribuição de mesteranas
 [github]("https://github.com/ahmedthebest31/navsounds")
[doações]("https://www.paypal.me/ahmedthebest31")

Alterne facilmente entre ativar e desativar sons de objetos e sons de digitação do teclado com um simples gesto de teclado NVDA + alt + n e você pode personalizá-lo como quiser no menu nvda aberto, subMenu Preferências, Gestos de entrada, sons de navegação.
Acesse uma página de configurações onde você pode escolher entre vários pacotes de sons de navegação/efeitos sonoros de digitação no teclado e configurar opções adicionais.
 inclui uma seleção de pacotes de som/efeitos sonoros de teclado de digitação, e você pode até criar e adicionar seus pacotes personalizados.


Contribuições para este projeto são bem-vindas! Se você encontrar um bug, tiver uma ideia para uma melhoria ou quiser contribuir de qualquer outra forma, sinta-se à vontade para abrir um problema ou enviar uma solicitação pull.

Agradecimentos especiais para  [mesteranas](https://github.com/mesteranas/) por suas maravilhosas contribuições no desenvolvimento deste complemento comigo.
Traduzido para Português do Brasil por Eduardo Araújo [edu-mx](https://github.com/edu-mx/)